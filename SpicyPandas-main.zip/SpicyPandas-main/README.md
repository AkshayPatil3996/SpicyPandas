# SpicyPandas webserver

This is my first real repo that i am soley creating to experiment with CopdeDeploy and CICD strategys as well as learning how appspec files work.
In this repo so far is my app spec file and some scripts and and index.html file for me to use for my webserver. 
