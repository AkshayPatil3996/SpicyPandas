#!/bin/bash
yum install httpd -y
